// getAssetTable.js - in Node, this file gets the current asset table and saves it to a file 

const axios = require("axios");
const fs = require("fs");

const getAssetTable = async () => {
  try {
  // get data from geopop API
    const response = await axios.get("https://dev-rhglanding.rhombuspower.com/geopop/api/geopop/tables/assets");

  // convert the response into JSON string
    const jsonData = JSON.stringify(response.data, null, 2);

  // write data out to a file
    fs.writeFile("public/data/assets.json", jsonData, (err) => {
      if (err) {
        console.error("Error writing file:", err);
        return;
      }
      console.log("Data successfully written to assets.json");
    });
  } catch (error) {
    console.error("Error getting data:", error);
  }
};

getAssetTable();